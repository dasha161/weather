const cityInput = document.getElementById('city');
const searchButton = document.getElementById('search');
const weatherInfo = document.getElementById('weatherInfo');
const loader = document.getElementById('loader');

searchButton.addEventListener('click', getWeather);
cityInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        getWeather();
    }
});

function getWeather() {
    const city = cityInput.value.trim();
    if (!city) {
        alert('Введите название города');
        return;
    }

    loader.style.display = 'block';
    fetch(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${API_KEY}&units=metric&lang=ru`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Ошибка при запросе данных');
            }
            return response.json();
        })
        .then(data => {
            loader.style.display = 'none';
            const temperature = data.main.temp;
            const weatherDescription = data.weather[0].description;
            const humidity = data.main.humidity;
            const windSpeed = data.wind.speed;

            weatherInfo.innerHTML = `
                <p>Температура: ${temperature}°C</p>
                <p>Погода: ${weatherDescription}</p>
                <p>Влажность: ${humidity}%</p>
                <p>Ветер: ${windSpeed} м/с</p>
            `;
        })
        .catch(error => {
            loader.style.display = 'none';
            if (error.message === 'Failed to fetch') {
                alert('Отсутствует интернет-соединение');
            } else {
                alert('Неверное название города или ошибка запроса');
            }
        });
}
